import { Component, OnInit, ViewContainerRef, NgModule, OnDestroy } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthGuard } from '../shared/_guards/index';
import { Router, CanActivate } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { AlertService } from '../services/alert.service';
import * as _ from 'underscore';
import { PagerService } from '../services/pager.service';
import { ApiServicesService } from '../services/api-services.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { forEach } from "@angular/router/src/utils/collection";
import { RfisService } from '../services/rfis/rfis.service';
import { ConfirmationDialogService } from '../services/confirm-dialog/confirmation-dialog.service';
@Component({
    selector: 'app-rfis',
    templateUrl: './rfis.component.html',
    styleUrls: ['./rfis.component.css']
})
export class RfisComponent implements OnInit {
    key: string = 'subject';
    form: FormGroup;
    reverse: boolean = true;
    sort(key) {
        this.key = key;
        this.reverse = !this.reverse;
    }
    preloaderImagePath: string; closeResult: string; isPreloaderShown: boolean = true; isNoDataShown: boolean = false; subjectName: string;
    column: string = 'subject'; rfisCount: number; p: number = 1;
    columnPriorities = []; rfis = []; rfiDetailsArr = []; isAddNewRFIEnabled: boolean = false; _projectIdRFI: string; _docIdRFI: string; _docTimestamp: string;
    searchString: string; subjectSearchString: string; lastMessageSearchString: string; authorSearchString: string; documentSearchString: string; dateSearchString: string;
    rfiRolenamesList = []; rfiSelectedItems = []; rfiExistingSelectedItems = []; rfiRolenamesDropdownSettings = {};
    formStartRFI: any; formCommentExitingRFI: any; rfiFiles: string[] = [];
    subject: string; comment: string; rfiIdStr: string;
    docName: string;
    docNameShown: boolean = false; isDisabled: boolean = false; isClosed: boolean = false;
    rfiStatus: boolean; rfiOpenText: string; rfiCloseText: string; rfiOpenColour: string; rfiCloseColour: string; rfiSize: string;
    commentView: string;
    constructor(private _authGuard: AuthGuard, private _router: Router, private _alertService: AlertService, private _pagerService: PagerService, private _apiServicesService: ApiServicesService, private _formBuilder: FormBuilder, private _loadingServices: Ng4LoadingSpinnerService, public _toastr: ToastsManager, vcr: ViewContainerRef, private _modalService: NgbModal, private _rfisService: RfisService, private _confirmDialogService: ConfirmationDialogService) { }

    ngOnInit() {
        if (!this._authGuard.canActivate()) {
            this._router.navigate(['/login']);
        }
        else {
            this.rfiOpenText = "Open";
            this.rfiCloseText = "Close";
            this.rfiOpenColour = "green";
            this.rfiCloseColour = "red";
            this.rfiSize = "mini";
            this.rfiStatus = true;
            this.rfiRolenamesDropdownSettings = {
                singleSelection: false,
                text: "To",
                selectAllText: 'Select All',
                unSelectAllText: 'UnSelect All',
                enableSearchFilter: true,
                classes: "rfis-to"
            };
            var currentDocRFI = JSON.parse(localStorage.getItem('docRFI'));
            if (currentDocRFI != null) {
                console.log("docId :" + currentDocRFI.docId)
                console.log("projectId :" + currentDocRFI.projectId)
                console.log("timestamp :" + currentDocRFI.timestamp)
                console.log("docName :" + currentDocRFI.docName)
                this.isAddNewRFIEnabled = true;
                this.docName = currentDocRFI.docName;
                this.docNameShown = true;
                this.getRFIRoleNames(currentDocRFI.projectId);
            }
            this.preloaderImagePath = this._apiServicesService.getApiBaseUrlDirectoryName();
            this.getRFISummary((currentDocRFI != null ? currentDocRFI.docId : ""), (currentDocRFI != null ? currentDocRFI.projectId : ""), (currentDocRFI != null ? currentDocRFI.timestamp : ""));
            this.getGridColumnPriorities();
            this.sort(this.column);
            this.formStartRFI = this._formBuilder.group({
                'subject': ['', Validators.required],
                'comment': ['', Validators.required]
            });

            this.formCommentExitingRFI = this._formBuilder.group({
                //'to': ['', Validators.nullValidator],
                'commentView': ['', Validators.required]
            });
        }
    }

    ngOnDestroy() {
        localStorage.removeItem('docRFI');
    }

    onItemSelect(item: any) {
        console.log(item);
        console.log(this.rfiSelectedItems);
    }
    OnItemDeSelect(item: any) {
        console.log(item);
        console.log(this.rfiSelectedItems);
    }
    onSelectAll(items: any) {
        console.log(items);
    }
    onDeSelectAll(items: any) {
        console.log(items);
    }

    //function to set grid column on the priority basis on narrow screens
    getGridColumnPriorities() {
        this.columnPriorities = [];
        var obj = {
            "subject": "one",
            "lastMessage": "two",
            "author": "three",
            "document": "four",
            "date": "five"
        }
        this.columnPriorities.push(obj);
    }

    //Function for getting a response from API for RFI summary
    getRFISummary(document_id, projectId, timestamp) {
        this._rfisService.getRFISummary(document_id, projectId, timestamp)
            .subscribe(res => {
                this.isPreloaderShown = false;
                if (res.json().length > 0) {
                    this.rfis = [];
                    for (var i = 0; i < res.json().length; i++) {
                        var rfi = {
                            'rfiId': res.json()[i]._id,
                            'subject': res.json()[i].subject != '' ? res.json()[i].subject : '',
                            'lastMessage': (res.json()[i].text.toString() != '' ? res.json()[i].text.toString().substring(0, 100) : ""),
                            'lastMessage_tooltip': res.json()[i].text != '' ? res.json()[i].text : '',
                            'author': res.json()[i].author != '' ? res.json()[i].author : '',
                            'documents': res.json()[i].documents != '' ? res.json()[i].documents : '',
                            'date': res.json()[i].date != '' ? res.json()[i].date : '',
                            'closeable': res.json()[i].closeable,
                            'isClosed': res.json()[i].closed
                        }
                        this.rfis.push(rfi);
                    }
                    this.rfisCount = this.rfis.length;
                    this.isNoDataShown = false;
                    this._loadingServices.hide();
                }
                else {
                    this._loadingServices.hide();
                    this.isNoDataShown = true;
                }
            },
            error => {
                this._loadingServices.hide();
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            });
    }

    //Function for getting RFI Role Names
    getRFIRoleNames(projectId) {
        this._rfisService.getRfiRoleNames(projectId)
            .subscribe(res => {
                let resSTR = JSON.stringify(res);
                let resJSON = JSON.parse(resSTR)
                var rolesString = (resJSON._body.toString() != null && resJSON._body.toString() != '' ? resJSON._body.toString().substr(1).slice(0, -2) : "");
                var rolesNameArr = rolesString.split(',');
                if (rolesNameArr.length > 0) {
                    this.rfiRolenamesList = [];
                    for (var i = 0; i < rolesNameArr.length; i++) {
                        var obj = {
                            "id": i,
                            "itemName": rolesNameArr[i]
                        }
                        this.rfiRolenamesList.push(obj);
                    }
                }
                else {
                    this.rfiRolenamesList = [];
                }
            })
    }

    //Function for open modal pop-up for View Last Messages
    openViewLastMessagesModal(content, rfiId, subjectName, typeClosable, IsClosed) {
        console.log("rfiId :" + rfiId)
        this.commentView = null;
        this.rfiIdStr = rfiId;
        this.subjectName = subjectName;
        this.isDisabled = (IsClosed == true ? true : (typeClosable == true ? false : true));
        this.rfiStatus = (IsClosed == true ? false : true);
        this.rfiCloseText = (IsClosed == true ? "Closed" : "Close");
        this.isClosed = IsClosed;
        this._rfisService.getRFIDetails(rfiId)
            .subscribe(res => {
                if (res.json().length > 0) {
                    this.rfiDetailsArr = [];
                    for (var i = 0; i < res.json().length; i++) {
                        var rfi = {
                            'timestamp': res.json()[i].timestamp,
                            'own': res.json()[i].own,
                            'text': res.json()[i].text,
                            'sender': res.json()[i].sender,
                            'attachments': res.json()[i].attachments
                        }
                        this.rfiDetailsArr.push(rfi);
                    }
                }
                else {
                    this.rfiDetailsArr = [];
                }
            },
            error => {
                this.rfiDetailsArr = [];
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            });
        this._modalService.open(content, { centered: true }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    //Function for open modal pop-up for Add New label
    openNewRFISModal(content) {
        this._modalService.open(content, { centered: true }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    //Function for to start a new RFI 
    startRFISubmit() {
        if (this.rfiSelectedItems.length > 0) {
            var roleNameStr = Array.prototype.map.call(this.rfiSelectedItems, s => s.itemName).toString();
            var currentDocRFI = JSON.parse(localStorage.getItem('docRFI'));
            this._rfisService.docRFIStart(currentDocRFI.projectId, currentDocRFI.docId, currentDocRFI.timestamp, this.formStartRFI.value.subject, this.formStartRFI.value.comment, roleNameStr)
                .subscribe(res => {
                    if (res.status == 200) {
                        this._toastr.success('The RFI has been started successfully.', 'Success !', { toastLife: 3000 });
                        this.getRFISummary(currentDocRFI.docId, currentDocRFI.projectId, currentDocRFI.timestamp);
                        $(".modal .close").trigger('click');
                    }
                    else {
                        this._loadingServices.hide();
                        this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                    }
                },
                error => {
                    this._loadingServices.hide();
                    this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
                });

        } else {
            this._toastr.error('Please select a recipient', 'Error !', { toastLife: 3000 });
        }
    }

    //Function for to comment on RFI's 
    commentRFISubmit() {
        console.log(this.rfiIdStr)
        console.log(this.formCommentExitingRFI.value.commentView)
        var currentDocRFI = JSON.parse(localStorage.getItem('docRFI'));
        this._rfisService.rfiUpdateComment(this.rfiIdStr, this.formCommentExitingRFI.value.commentView)
            .subscribe(res => {
                if (res.status == 200) {
                    this._toastr.success('The RFI has been updated successfully.', 'Success !', { toastLife: 3000 });
                    this.getRFISummary((currentDocRFI != null ? currentDocRFI.docId : ""), (currentDocRFI != null ? currentDocRFI.projectId : ""), (currentDocRFI != null ? currentDocRFI.timestamp : ""));
                    $(".modal .close").trigger('click');
                    this.commentView = null;
                }
                else {
                    this._loadingServices.hide();
                    this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                }
            },
            error => {
                this._loadingServices.hide();
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            });
    }

    //Function for getting the files which need to upload
    getFileDetails(e) {
        this.rfiFiles = [];
        for (var i = 0; i < e.target.files.length; i++) {
            this.rfiFiles.push(e.target.files[i]);
        }
    }

    //Function for closed the RFI
    onStatusChange(event, rfiId) {
        if (event == true) {
            console.log(event)
        }
        else {
            this._confirmDialogService.confirm('Confirmation', 'Are you sure you want to close the RFI?')
                .then((confirmed) => {
                    if (confirmed) {
                        console.log("RFI ID :" + rfiId)
                        this._rfisService.rfiClose(rfiId)
                            .subscribe(res => {
                                if (res.status == 200) {
                                    this._toastr.success('The RFI has been closed successfully.', 'Success !', { toastLife: 3000 });
                                    var currentDocRFI = JSON.parse(localStorage.getItem('docRFI'));
                                    this.getRFISummary((currentDocRFI != null ? currentDocRFI.docId : ""), (currentDocRFI != null ? currentDocRFI.projectId : ""), (currentDocRFI != null ? currentDocRFI.timestamp : ""));
                                    $(".modal .close").trigger('click');
                                }
                                else {
                                    $("div.bootstrap-switch-container").trigger('click');
                                    this._loadingServices.hide();
                                    this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                                }
                            },
                            error => {
                                $("div.bootstrap-switch-container").trigger('click');
                                this._loadingServices.hide();
                                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
                            });
                    }
                    else {
                        $("div.bootstrap-switch-container").trigger('click');
                        $("body").addClass("modal-open");
                    }
                })
                .catch(() => {
                    $("div.bootstrap-switch-container").trigger('click');
                    $("body").addClass("modal-open");
                })
        }
    }

    //Function for dismissing modal pop-up
    private getDismissReason(reason: any): string {
        this.subject = null;
        this.comment = null;
        this.rfiSelectedItems = [];
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}


