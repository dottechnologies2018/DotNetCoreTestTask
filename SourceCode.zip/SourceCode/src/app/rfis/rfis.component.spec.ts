import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RfisComponent } from './rfis.component';

describe('RfisComponent', () => {
  let component: RfisComponent;
  let fixture: ComponentFixture<RfisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RfisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RfisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
