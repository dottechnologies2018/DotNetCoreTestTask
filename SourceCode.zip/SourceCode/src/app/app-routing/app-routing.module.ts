import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { GeneralInfoComponent } from '../general-info/general-info.component';
import { ContactUsComponent } from '../contact-us/contact-us.component';
import { SecureRouteComponent, SECURE_ROUTES } from '../layout/secure-route';
import { AuthGuard } from '../shared/_guards/index';
import { DocComponent } from '../doc/doc.component';
import { RfisComponent } from '../rfis/rfis.component';
import { PaymentsComponent } from '../payments/payments.component';
import { MapsComponent } from '../maps/maps.component';
import { NotificationsComponent } from '../notifications/notifications.component';
import { TasksComponent } from '../tasks/tasks.component';
import { SystemadminComponent } from '../systemadmin/systemadmin.component';
import { CommentsComponent } from '../comments/comments.component';
import { UserManagementComponent } from '../user-management/user-management.component';

const routes: Routes = [
    { path: '',component: SecureRouteComponent,canActivate: [AuthGuard], 
        children: [
            { path: 'dashboard', component: DashboardComponent, data: { title: 'Dashboard'}},
            { path: 'doc', component: DocComponent, data: { title: 'Doc', breadcrumb: "DOC" }},       
            { path: 'rfis', component: RfisComponent, data: { title: 'RFIS', breadcrumb: "RFIS" } },
            { path: 'comments', component: CommentsComponent, data: { title: 'comments', breadcrumb: "COMMENTS" } },
            { path: 'payments', component: PaymentsComponent, data: { title: 'Payments', breadcrumb: "PAYMENTS" }},
            { path: 'maps', component: MapsComponent, data: { title: 'Maps', breadcrumb: "MAPS" }},
            { path: 'notifications', component: NotificationsComponent, data: { title: 'Notifications', breadcrumb: "NOTIFICATIONS" } },
            { path: 'tasks', component: TasksComponent, data: { title: 'Tasks', breadcrumb: "TASKS" }},
            { path: 'systemadmin', component: SystemadminComponent, data: { title: 'System Admin', breadcrumb: "SYSTEM ADMIN" } },
            { path: 'user-management', component: UserManagementComponent, data: { title: 'User Management', breadcrumb: "USER MANAGEMENT" } }               

        ],       
    },
    { path: 'login', component: LoginComponent },
    { path: 'generalInfo', component: GeneralInfoComponent },
    { path: 'contactUs', component: ContactUsComponent },
    { path: '**', redirectTo: 'login' },
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ],
    declarations: []
})
export class AppRoutingModule { }
