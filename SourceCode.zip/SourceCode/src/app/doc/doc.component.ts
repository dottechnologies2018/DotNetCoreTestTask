import { Component, OnInit, ViewContainerRef, NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthGuard } from '../shared/_guards/index';
import { Router, CanActivate } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { AlertService } from '../services/alert.service';
import { DocService } from '../services/doc/doc.service';
import * as _ from 'underscore';
import { PagerService } from '../services/pager.service';
import { ApiServicesService } from '../services/api-services.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { forEach } from "@angular/router/src/utils/collection";
import { ManagelabelService } from '../services/managelabel/managelabel.service';
import { CommonService } from '../services/common.service';
@Component({
    selector: 'app-doc',
    templateUrl: './doc.component.html',
    styleUrls: ['./doc.component.css']
})
export class DocComponent implements OnInit {
    key: string = 'name';
    reverse: boolean = true;
    sort(key) {
        this.key = key;
        this.reverse = !this.reverse;
    }
    //Confirm modal pop up settings
    options: any = {
        confirmBtnClass: 'btn btn-dark',
        confirmBtnText: 'Delete',
        cancelBtnClass: 'btn btn-dark',
        cancelBtnText: 'Cancel',
        modalSize: 'sm',
        modalClass: 'login-bg-dark confirm-modal'
    }
    p: number = 1; form: FormGroup; docs: any[]; docsCount: number; public searchString: string;
    column: string = 'name'; direction: number; isPreloaderShown: boolean = true; isPreloaderShownLabel: boolean = true;
    isNoDataShown: boolean = false; isNoDataShownLabel: boolean = false; formAddNewLabel: any; formAssignLabel: any;
    nameSearchString: string; projectSearchString: string; labelsSearchString: string; string; authorSearchString: string; typeSearchString: string; dateSearchString: string; preloaderImagePath: string;
    closeResult: string;
    userLabelList = []; userLabelSelectedItems = [];
    documentVersionArr = []; myFiles: string[] = [];
    docId: string; projectId: string; labelname: string;
    selectedDocList = []; savedLabelsfiltered: any[]; systemLabelsList = []; selectedLabelsList = []; labelListForDocAssignOrDeAssign = []; userDefinedLabelList = [];
    groupDownloadProjectIds = [];
    flag: boolean = false;
    deleteLabelFlag: boolean = false;

    //Labels priorities variables
    columnPriorities = []; labelsPriorities: string; authorPriorities: string; typePriorities: string; datePriorities: string; phasePriorities: string; systemLabelsString: string;

    //Constructor initialization  
    constructor(private _authGuard: AuthGuard, private _router: Router, private _alertService: AlertService, private _docService: DocService, private _pagerService: PagerService, private _apiServicesService: ApiServicesService, private _formBuilder: FormBuilder, private _loadingServices: Ng4LoadingSpinnerService, public _toastr: ToastsManager, vcr: ViewContainerRef, private _modalService: NgbModal, private _manageLabelService: ManagelabelService, private _helper: CommonService) {
    }

    //Page initialization
    ngOnInit() {
        if (!this._authGuard.canActivate()) {
            this._router.navigate(['/login']);
        }
        else {
            this._helper.calculateGridHeight();
            var currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser.document_filter_labels[0] != "") {
                this.savedLabelsfiltered = currentUser.document_filter_labels;
            }
            else {
                this.savedLabelsfiltered = [];
            }
            this.preloaderImagePath = this._apiServicesService.getApiBaseUrlDirectoryName();
            this.getDocumentsSummary("");
            this.getGridColumnPriorities();
            this.sort(this.column);
            //this code is validate the Add New Label field in Manage Labels pop-up
            this.formAddNewLabel = this._formBuilder.group({
                'labelname': ['', Validators.required]
            });
        }
    }

    //Function to set grid column on the priority basis on narrow screens
    getGridColumnPriorities() {
        this.columnPriorities = [];
        var obj = {
            "labels": "one",
            "author": "two",
            "type": "three",
            "date": "four",
            "project": "five"
        }
        this.columnPriorities.push(obj);
    }

    //Function for getting a response from API for document summary
    getDocumentsSummary(typeOfOperation) {
        this._docService.getDocumentsSummary()
            .subscribe(res => {
                this.isPreloaderShown = false;
                if (res.json().length > 0) {
                    this.systemLabelsString = res.json().map((obj => obj.labels.system)).toString();
                    this.getUserDefinedlablesList();
                    var data = [];
                    for (var i = 0; i < res.json().length; i++) {
                        var doc = {
                            '_id': res.json()[i]._id != '' ? res.json()[i]._id : '',
                            'project_id': res.json()[i].project_id != '' ? res.json()[i].project_id : '',
                            'author': res.json()[i].author != '' ? res.json()[i].author : '',
                            'date': res.json()[i].date != '' ? res.json()[i].date : '',
                            'labels': res.json()[i].labels.all_csv,
                            'name': res.json()[i].name != '' ? res.json()[i].name : '',
                            'phase': res.json()[i].phase != '' ? res.json()[i].phase : '',
                            'type': res.json()[i].type != '' ? res.json()[i].type : '',
                            'project': res.json()[i].project_name != '' ? res.json()[i].project_name : '',
                            'system_labels': (res.json()[i].labels.system.toString() != '' ? res.json()[i].labels.system.toString().substring(0, 30) : ""),
                            'user_labels': (res.json()[i].labels.user.toString() != '' ? res.json()[i].labels.user.toString().substring(0, 30) : ""),
                            'system_labels_tooltip': res.json()[i].labels.system,
                            'user_labels_tooltip': res.json()[i].labels.user,
                            'has_versions': res.json()[i].has_versions,
                            'timestamp': res.json()[i].timestamp,
                            'selected': false
                        }
                        data.push(doc);
                    }
                    this.docs = this.filterDocBySavedLabel(data, this.savedLabelsfiltered);
                    this.docsCount = this.docs.length;
                    this._loadingServices.hide();
                    if (typeOfOperation == "assignLabel") {
                        this._toastr.success('The label has been assigned successfully.', 'Success !', { toastLife: 3000 });
                    }
                    if (typeOfOperation == "removeLabel") {
                        this._toastr.success('The label has been removed successfully.', 'Success !', { toastLife: 3000 });
                    }
                    if (typeOfOperation == "labelAssignment") {
                        this._toastr.success('The labels assignment has been saved successfully.', 'Success !', { toastLife: 3000 });
                    }
                    if (typeOfOperation == "labelDeAssignment") {
                        this._toastr.success('The labels De-assignment has been saved successfully.', 'Success !', { toastLife: 3000 });
                    }
                    if (typeOfOperation == "filteredLabels") {
                        this._toastr.success('The filtered labels has been saved successfully.', 'Success !', { toastLife: 3000 });
                    }
                }
                else {
                    this._loadingServices.hide();
                    this.isNoDataShown = true;
                }
            },
            error => {
                this._loadingServices.hide();
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            });
    }

    //Function for getting a response from API for User defined labels list   
    getUserDefinedlablesList() {
        //getting saved label filter data      
        var tempUserLabelsArr = []; this.userLabelList = []; this.labelListForDocAssignOrDeAssign = []; this.userDefinedLabelList = [];
        this._docService.getUserLablesList()
            .subscribe(res => {
                this.isPreloaderShownLabel = false;
                if (res.json().length > 0) {
                    this.isNoDataShownLabel = false;
                    this.userLabelList = [];
                    //code for fetching custom labels temporary
                    for (var i = 0; i < res.json().length; i++) {
                        var objCustom = {
                            'itemName': res.json()[i].name,
                            "color": "#458e45",
                            "selected": false
                        }
                        tempUserLabelsArr.push(objCustom);
                        this.userDefinedLabelList.push(objCustom);
                    }
                    //code for fetching system labels temporary
                    if (this.systemLabelsString != '' && this.systemLabelsString != null) {
                        let systemLabelsArr = this._helper.convertStringToArray(this.systemLabelsString).toString().split(",");
                        if (systemLabelsArr.length > 0) {
                            for (var i = 0; i < systemLabelsArr.length; i++) {
                                var objSystem = {
                                    'itemName': systemLabelsArr[i],
                                    "color": "#5b98e0",
                                    "selected": false
                                }
                                tempUserLabelsArr.push(objSystem);
                            }
                        }
                        else {
                            console.log("system labels are empty")
                        }
                    }
                    //code for merging both temporary custom and system labels               
                    if (this.savedLabelsfiltered.length > 0) {
                        for (var j = 0; j < this.savedLabelsfiltered.length; j++) {
                            let obj = tempUserLabelsArr.find((o, i) => {
                                if (o.itemName === this.savedLabelsfiltered[j]) {
                                    tempUserLabelsArr[i] = {
                                        "itemName": o.itemName,
                                        "color": o.color,
                                        "selected": true
                                    };
                                    return true; // stop searching
                                }
                            });
                        }
                        for (var i = 0; i < tempUserLabelsArr.length; i++) {
                            var obj = {
                                'itemName': tempUserLabelsArr[i].itemName,
                                "color": tempUserLabelsArr[i].color,
                                "selected": tempUserLabelsArr[i].selected
                            }
                            this.userLabelList.push(obj);
                        }
                    }
                    else {
                        for (var i = 0; i < tempUserLabelsArr.length; i++) {
                            var objLabel = {
                                'itemName': tempUserLabelsArr[i].itemName,
                                "color": tempUserLabelsArr[i].color,
                                "selected": ''
                            }
                            this.userLabelList.push(objLabel);
                        }
                    }
                }
                else {
                    this.isNoDataShownLabel = true;
                }
            },
            error => {
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            })
    }

    //Function for getting filtered Doc by labels
    filterDocBySavedLabel(docCollectionsArray, filterdLabelsArray) {
        var result = [];
        var finalList = [];
        if (filterdLabelsArray != '' && filterdLabelsArray != null && filterdLabelsArray.length > 0) {
            if (filterdLabelsArray[0] != "") {
                var found = false;
                for (var i = 0; i < docCollectionsArray.length; i++) {
                    if (docCollectionsArray[i].labels != '') {
                        var _labelsCollection = docCollectionsArray[i].labels.split(",");
                        for (var k = 0; k < _labelsCollection.length; k++) {
                            for (var j = 0; j < filterdLabelsArray.length; j++) {
                                if (_labelsCollection[k] === filterdLabelsArray[j]) {
                                    result.push(docCollectionsArray[i])
                                }
                            }
                        }
                    }
                }
                finalList = this._helper.removeDuplicates(result, "_id");
                return finalList;
            }
            else {
                return docCollectionsArray;
            }
        }
        else {
            return docCollectionsArray;
        }
    }

    //Function for open the filter label modal pop-up
    openSortFilterLabelModal(content, key) {
        this._modalService.open(content, { centered: true, windowClass: "label-filter" }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReasonFilterLabel(reason)}`;
        });
    }

    //Function for saving filtered label in DB
    filterLabel() {
        console.log(this.selectedLabelsList.toString())
        var result = this.selectedLabelsList.toString();
        var convertLabelsToArray = (result != '' ? result.split(',') : []);
        console.log(convertLabelsToArray)
        this._loadingServices.show();
        this.savedLabelsfiltered = convertLabelsToArray;
        this.getDocumentsSummary("");
        $(".modal .close").trigger('click');
        //this._docService.filterLabelsSave(result)
        //    .subscribe(res => {
        //        if (res.status == 200) {
        //            this.savedLabelsfiltered = convertLabelsToArray;
        //            this.getDocumentsSummary("filteredLabels");
        //            $(".modal .close").trigger('click');
        //        }
        //        else {
        //            this._loadingServices.hide();
        //            this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
        //        }
        //    },
        //    error => {
        //        this._loadingServices.hide();
        //        this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
        //    });
    }

    //Function for removing label from Doc
    deleteLabelDoc(item) {
        this._loadingServices.show();
        $(".modal .close").trigger('click');
        this._docService.removeLabelToDoc(item.itemName, this.docId)
            .subscribe(res => {
                if (res.status == 200) {
                    this.getDocumentsSummary("removeLabel");
                    this.getUserDefinedlablesList();
                    this.selectedDocList = [];
                    this.groupDownloadProjectIds = [];
                }
                else {
                    this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                    this._loadingServices.hide();
                }
            },
            error => {
                this._loadingServices.hide();
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            });
    }

    //Function for getting document download modal pop-up
    openDocumentVersionModal(content, docId, project_id) {
        this._docService.getDocumentVersion(docId, project_id)
            .subscribe(res => {
                if (res.json().length > 0) {
                    this.documentVersionArr = [];
                    for (var i = 0; i < res.json().length; i++) {
                        var filename = this._helper.removeSpecialCharacterFromString(res.json()[i].filename);
                        var data = {
                            'docId': docId,
                            'author': res.json()[i].author,
                            'filename': res.json()[i].filename,
                            'timestamp': res.json()[i].timestamp,
                            'datetime': res.json()[i].datetime,
                            'documentDownloadPath': this._docService.getDocumentDownloadPath() + '/' + filename + '?document_master_id=' + docId + '&timestamp=' + res.json()[i].timestamp
                        }
                        this.documentVersionArr.push(data);
                    }
                }
                else {
                    this.isNoDataShown = true;
                }
                this._modalService.open(content, { centered: true }).result.then((result) => {
                    this.closeResult = `Closed with: ${result}`;
                }, (reason) => {
                    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
                });
            },
            error => {
                this._toastr.error("Something is went wrong, contact site administrator", "Error !", { toastLife: 3000 });
            });
    }

    //Function for getting the latest uploaded document file
    getLatestDocFile(docId, project_id) {
        this._docService.getDocumentVersion(docId, project_id)
            .subscribe(res => {
                if (res.json().length > 0) {
                    var filename = this._helper.removeSpecialCharacterFromString(res.json()[res.json().length - 1].filename);
                    console.log(filename);
                    var downloadPath = this._docService.getDocumentDownloadPath() + '/' + filename + '?document_master_id=' + docId + '&timestamp=' + res.json()[res.json().length - 1].timestamp;
                    window.open(downloadPath, '_blank');
                }
                else {
                    this._toastr.error('No document found', 'Error !', { toastLife: 3000 });
                    return false;
                }
            });
    }

    //Function for getting the upload document modal pop-up
    openDocumentUploadModal(content, docId, project_id) {
        this.docId = docId;
        this.projectId = project_id;
        this._modalService.open(content, { centered: true }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    //Function for getting count of selected files to upload
    getFileDetails(e) {
        this.myFiles = [];
        for (var i = 0; i < e.target.files.length; i++) {
            //if (!e.target.files[i].type.match('application/pdf')) {
            //    $("#file").val('');
            //    $(".modal .close").trigger('click');
            //    this._toastr.error("You can upload only .pdf extension file.", 'Error !', { toastLife: 5000 });
            //    this.myFiles = [];
            //    return false;
            //}
            this.myFiles.push(e.target.files[i]);
        }
        $("#selectedFileCount").text((this.myFiles.length > 0 ? this.myFiles.length + ' files' : ''));

    }

    //Function for upload document's
    uploadFiles() {
        this._loadingServices.show();
        $(".modal .close").trigger('click');
        if (this.myFiles.length > 0) {
            for (var i = 0; i < this.myFiles.length; i++) {
                this._docService.uploadDocToDoc(this.projectId, this.docId, this.myFiles[i])
                    .subscribe(res => {
                        if (res.status == 200) {
                            this._toastr.success('The file has been uploaded successfully.', 'Success !', { toastLife: 3000 });
                            this.getDocumentsSummary("");
                        }
                        else {
                            this._loadingServices.hide();
                            this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                        }
                    },
                    error => {
                        this._loadingServices.hide();
                        this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
                    });
            }
        }
        else {
            this._loadingServices.hide();
            this._toastr.error("Please select a file for upload.", 'Error !', { toastLife: 3000 });
        }
        this.myFiles = [];
    }

    //Function for open modal pop-up for Add New label
    openNewLabelModal(content) {
        this._modalService.open(content, { centered: true }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReasonAddNewLabel(reason)}`;
        });
    }

    //Function for retrieving selected doc id's in string array
    selectedDoc(ev, val, project_id) {
        if (ev.target.checked) {
            this.selectedDocList.push(val);
            this.groupDownloadProjectIds.push(project_id);
        } else {
            let i = this.selectedDocList.indexOf(val);
            let _projectid = this.selectedDocList.indexOf(project_id);
            this.selectedDocList.splice(i, 1);
            this.groupDownloadProjectIds.splice(_projectid, 1);
        }
    }

    //Function for showing filtered or saved labels
    getSavedfilteredLabels(userLabelList) {
        var labelListArr = [];
        labelListArr.push(userLabelList);
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser._id != "") {
            for (var i = 0; i < currentUser.document_filter_labels.length; i++) {
                this.savedLabelsfiltered = currentUser.document_filter_labels;
                for (var j = 0; j < labelListArr.length; j++) {
                    if (currentUser.document_filter_labels[i] == labelListArr[j].itemName) {
                        var label = {
                            "id": this.userLabelList[j].id,
                            "itemName": currentUser.document_filter_labels[i],
                            "category": "Custom Labels"
                        }
                        this.userLabelList.push(label);
                    }
                    else {
                    }
                }
            }
        }
    }

    //Function for group download files
    groupDownloadClick() {
        if (this.selectedDocList.length > 0) {
            this._loadingServices.show();
            var docIds = this.selectedDocList.toString();
            var projectIds = this.groupDownloadProjectIds.toString();
            this._docService.groupDownloadDocs(docIds, projectIds);
            this._loadingServices.hide();
        }
        else {
            this._loadingServices.hide();
            this._toastr.error('Please select a document first.', 'Error !', { toastLife: 3000 });
        }
    }

    //Function to select all document id's
    selectAll(ev) {
        this.selectedDocList = [];
        this.groupDownloadProjectIds = [];
        if (ev.target.checked) {
            for (var i = 0; i < this.docs.length; i++) {
                this.docs[i].selected = true;
                this.selectedDocList.push(this.docs[i]._id);
                this.groupDownloadProjectIds.push(this.docs[i].project_id);
            }
        }
        else {
            for (var j = 0; j < this.docs.length; j++) {
                this.docs[j].selected = false;
                let i = this.selectedDocList.indexOf(this.docs[j]._id);
                let project_id = this.selectedDocList.indexOf(this.docs[j].project_id);
                this.selectedDocList.splice(i, 1);
                this.groupDownloadProjectIds.splice(project_id, 1);
            }
        }
    }

    cancelled() {
        console.log('canceled');
        $("body").addClass("modal-open");
    }

    //Function for getting Document group labels modal pop-up
    openAssignmentLabelModal(content) {
        if (this.selectedDocList.length > 0) {
            this.flag = false;
            this.getAddedDocGrouplabel(this.selectedDocList.toString());
            this._modalService.open(content, { centered: true, windowClass: "label-filter" }).result.then((result) => {
                this.closeResult = `Closed with: ${result}`;
            }, (reason) => {
                this.closeResult = `Dismissed ${this.getDismissReasonGroupLabel(reason)}`;
            });
            $("div.modal-body").find('.dropdown-list').addClass("custom-list-shown");
            $(".modal-body").click(function () {
                $("div.modal-body").find('.dropdown-list').removeClass("custom-list-shown");
            });
        }
        else {
            this._toastr.error('Please select a document first.', 'Error !', { toastLife: 3000 });
        }
    }

    //Function for retrieving selected label's in a string array
    selectedLabelToAssign(ev, labelName) {
        console.log(labelName)
        if (ev.target.checked) {
            this.onLabelCheck(labelName);
        } else {
            this.deleteGroupLabelDoc(labelName);
        }
    }

    //Function for reverting already assigns labels in Document group labels
    getAddedDocGrouplabel(docIds) {
        this.labelListForDocAssignOrDeAssign = [];
        this._docService.getUserLablesList()
            .subscribe(res => {
                if (res.json().length > 0) {
                    //code for fetching custom labels temporary
                    for (var i = 0; i < res.json().length; i++) {
                        var objCustom = {
                            'itemName': res.json()[i].name,
                            "color": "#458e45",
                            "selected": false
                        }
                        this.labelListForDocAssignOrDeAssign.push(objCustom);
                    }
                    this._docService.getDocumentGroupLabels(docIds)
                        .subscribe(res => {
                            let resSTR = JSON.stringify(res);
                            let resJSON = JSON.parse(resSTR)
                            var data = [];
                            if (resJSON.status == 200) {
                                //remove new line from string response
                                var responseStr = resJSON._body.replace(/[\r\n]/g, '')
                                console.log(responseStr)
                                var groupLabelsArr = responseStr.split(',');
                                for (var j = 0; j < groupLabelsArr.length; j++) {
                                    let obj = this.labelListForDocAssignOrDeAssign.find((o, i) => {
                                        if (o.itemName === groupLabelsArr[j]) {
                                            this.labelListForDocAssignOrDeAssign[i] = {
                                                "itemName": o.itemName,
                                                "color": o.color,
                                                "selected": true
                                            };
                                            return true; // stop searching
                                        }
                                    });
                                }
                                console.log(this.labelListForDocAssignOrDeAssign)
                            }
                        });
                }
            });
    }

    //Function for saving labels in DB for doc
    onLabelCheck(labelItem) {
        if (this.selectedDocList.length > 0) {
            var selectedLabels = [];
            selectedLabels.push(labelItem);
            console.log(selectedLabels)
            if (selectedLabels.length > 0) {
                this._loadingServices.show();
                this._docService.multipleLabelAssignmentToDocs(this.selectedDocList, selectedLabels)
                    .subscribe(res => {
                        if (res.status == 200) {
                            this._loadingServices.hide();
                            this.flag = true;
                            this._toastr.success('The label assignment has been saved successfully.', 'Success !', { toastLife: 3000 });
                        }
                        else {
                            this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                            this._loadingServices.hide();
                        }
                    },
                    error => {
                        this._loadingServices.hide();
                        this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
                    });
            }
            else {
                this._loadingServices.hide();
                $(".modal .close").trigger('click');
                this._toastr.error('Please select a label.', 'Error !', { toastLife: 3000 });
            }
        }
        else {
            this._loadingServices.hide();
            $(".modal .close").trigger('click');
            this._toastr.error('Please select a document first.', 'Error !', { toastLife: 3000 });
        }
    }

    //Function for deleting the label in group operation
    deleteGroupLabelDoc(labelValue) {
        if (this.selectedDocList.length > 0) {
            var selectedLabels = [];
            selectedLabels.push(labelValue);
            console.log(selectedLabels)
            if (selectedLabels.length > 0) {
                this._loadingServices.show();
                this._docService.multipleLabelDeAssignmentToDocs(this.selectedDocList, selectedLabels)
                    .subscribe(res => {
                        if (res.status == 200) {
                            this._loadingServices.hide();
                            this.flag = true;
                            this._toastr.success('The label has been deleted successfully.', 'Success !', { toastLife: 3000 });
                        }
                        else {
                            this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                            this._loadingServices.hide();
                        }
                    },
                    error => {
                        this._loadingServices.hide();
                        this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
                    });
            }
            else {
                this._loadingServices.hide();
                $(".modal .close").trigger('click');
                this._toastr.error('Please select a label.', 'Error !', { toastLife: 3000 });
            }
        }
        else {
            this._loadingServices.hide();
            $(".modal .close").trigger('click');
            this._toastr.error('Please select a document first.', 'Error !', { toastLife: 3000 });
        }
    }

    //Function for retrieving selected label's in a string array
    selectedLabel(ev, labelName) {
        if (ev.target.checked) {
            this.selectedLabelsList.push(labelName);
        } else {
            let i = this.selectedLabelsList.indexOf(labelName);
            this.selectedLabelsList.splice(i, 1);
        }
        console.log(this.selectedLabelsList)
    }

    //Function for redirecting to comment page 
    commentClick() {
        this._router.navigate(['/comments']);
    }

    //Function for redirecting to RFI page 
    rfisClick(docId, projectId, timestamp, docName) {
        var obj = {
            'docId': docId,
            'projectId': projectId,
            'timestamp': timestamp,
            'docName': docName
        }
        localStorage.setItem('docRFI', JSON.stringify(obj));
        this._router.navigate(['/rfis']);
    }

    //Function for Adding New Label
    addNewUserLabel() {
        if (this.formAddNewLabel.dirty && this.formAddNewLabel.valid) {
            var IsAddedLabelFlag = false;
            let obj = this.userDefinedLabelList.find((o, i) => {
                if (o.itemName.toString().toLowerCase().replace(/\s/g, "") === this.formAddNewLabel.value.labelname.toString().toLowerCase().replace(/\s/g, "")) {
                    IsAddedLabelFlag = true;
                    this._toastr.error('This label is already exists.', 'Error !', { toastLife: 3000 });
                    this.labelname = null;
                    return true; // stop searching
                }
            });
            if (!IsAddedLabelFlag) {
                this._loadingServices.show();
                this._manageLabelService.addUserLabel(this.formAddNewLabel.value.labelname)
                    .subscribe(res => {
                        console.log(res)
                        let resSTR = JSON.stringify(res);
                        let resJSON = JSON.parse(resSTR)
                        this._loadingServices.hide();
                        if (resJSON.status == 200) {
                            this._toastr.success('The label has been added successfully.', 'Success !', { toastLife: 3000 });
                            this.getUserDefinedlablesList();
                            this.labelname = null;
                            $(".modal .close").trigger('click');
                        }
                        else {
                            this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                        }
                    },
                    error => {
                        console.log(error)
                        this._loadingServices.hide();
                        this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
                    });
            }
        }
    }

    //Function for deleting Label
    deleteLabel(labelName) {
        $("body").addClass("modal-open");
        this._loadingServices.show();
        this.labelname = null;
        this._manageLabelService.deleteUserLabel(labelName)
            .subscribe(res => {
                this._loadingServices.hide();
                if (res.status == 200) {
                    this._toastr.success('The label has been deleted successfully.', 'Success !', { toastLife: 3000 });
                    this.deleteLabelFlag = true;
                    $(".modal .close").trigger('click');
                }
                else {
                    this._toastr.error('Something is went wrong, contact site administrator', 'Error !', { toastLife: 3000 });
                }
            },
            error => {
                this._loadingServices.hide();
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 3000 });
            });
    }

    //Function for dismissing the modal pop-up
    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    //Function for dismissing group label modal pop-up
    private getDismissReasonGroupLabel(reason: any): string {
        if (this.flag == true) {
            this._loadingServices.show();
            this.flag = false;
            this.selectedDocList = [];
            this.groupDownloadProjectIds = [];
            this.labelListForDocAssignOrDeAssign = [];
            this.getDocumentsSummary("");
        }
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    //Function for dismissing add new label modal pop-up
    private getDismissReasonAddNewLabel(reason: any): string {
        if (this.deleteLabelFlag == true) {
            this._loadingServices.show();
            this.deleteLabelFlag = false;
            this.selectedDocList = [];
            this.groupDownloadProjectIds = [];
            this.getDocumentsSummary("");
        }
        this.labelname = null;
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    //Function for dismissing filter label modal pop-up
    private getDismissReasonFilterLabel(reason: any): string {
        //this.selectedLabelsList = [];
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
