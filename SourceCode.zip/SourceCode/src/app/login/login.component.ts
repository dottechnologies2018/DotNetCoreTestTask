import { Component, OnInit, Output, EventEmitter, Input, TemplateRef} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../../app/services/validation.service';
import { AuthenticationService } from '../services/authentication.service';
import { AlertService } from '../services/alert.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
    
export class LoginComponent implements OnInit {
    form: FormGroup;
    loading = false;
    userForm: any;   
    closeResult: string;

    constructor(private formBuilder: FormBuilder, private router: Router, private authenticationService: AuthenticationService, private alertService: AlertService, private spinnerService: Ng4LoadingSpinnerService, private modalService: NgbModal) {}

    ngOnInit() {
        //check if user session exists then redirect to dashboard
        if (localStorage.getItem('currentUser')) {
            this.router.navigate(['/dashboard']);
        }
        //validation for login page
        this.userForm = this.formBuilder.group({
            'password': ['', Validators.required],
            'email': ['', [Validators.required, ValidationService.emailValidator]]
        });
    }


    //function to login into application
    login() {        
        //Check if form is valid to submit
        if (this.userForm.dirty && this.userForm.valid) {
            this.loading = true;
            this.spinnerService.show();
            this.authenticationService.login(this.userForm.value.email, this.userForm.value.password)
                .subscribe(res => {              
                    this.spinnerService.hide();
                    console.log(res);                
                    if (res._id != "") {                      
                        $(".modal .close").trigger('click');
                        localStorage.setItem('currentUser', JSON.stringify(res));   
                        this.router.navigate(['/dashboard']);
                    }
                    else {
                        this.alertErrorMessage('Email or password is incorrect');
                        this.loading = false;
                    }
                },
                error =>
                {
                    this.spinnerService.hide();
                    this.alertService.warn("Something is went wrong, contact site administrator");
                }
            );
        }
    }

    //function to show error alert message
    alertErrorMessage(message: string) {
        this.alertService.error(message);
    }

    open(content) {
        this.modalService.open(content, { windowClass: 'login-bg-dark', centered:true }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    } 

   
}


