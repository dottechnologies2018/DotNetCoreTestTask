import * as $ from 'jquery';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { NgModule } from '@angular/core';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule, JsonpModule } from '@angular/http';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { ConfirmationModalModule } from 'ng-confirmation-modal';
//import { FileUploaderModule } from "ng4-file-upload";
import { BootstrapSwitchModule } from 'angular2-bootstrap-switch';


/*registered components*/
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FieldErrorDisplayComponent } from './shared/field-error-display/field-error-display.component';
import { SecureRouteComponent } from './layout/secure-route/secure-route.component';
import { ControlMessagesComponent } from './control-messages.component';
import { AlertComponent } from './shared/_directives/alert/alert.component';
import { GeneralInfoComponent } from './general-info/general-info.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { DocComponent } from './doc/doc.component';
import { BreadcrumbComponent } from './shared/breadcrumb/breadcrumb.component';
import { RfisComponent } from './rfis/rfis.component';
import { PaymentsComponent } from './payments/payments.component';
import { MapsComponent } from './maps/maps.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { TasksComponent } from './tasks/tasks.component';
import { SystemadminComponent } from './systemadmin/systemadmin.component';
import { CommentsComponent } from './comments/comments.component';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { UserManagementComponent } from './user-management/user-management.component';

/*registered services*/
import { AuthGuard } from './shared/_guards/index';
import { AuthenticationService } from './services/authentication.service';
import { AlertService } from './services/alert.service';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { ApiServicesService } from './services/api-services.service';
import { DocService } from './services/doc/doc.service';
import { PagerService } from './services/pager.service';
import { ManagelabelService } from './services/managelabel/managelabel.service';
import { CommonService } from './services/common.service';
import { RfisService } from './services/rfis/rfis.service';
import { ConfirmationDialogService } from './services/confirm-dialog/confirmation-dialog.service';

/*registered pipes*/
import { FilterAllColumnPipe } from './shared/pipe/filter-all-column.pipe';
import { DocFilterPipe } from './shared/pipe/doc/doc-filter.pipe';
import { SortgridPipe } from './shared/pipe/sortgrid.pipe';
import { LabelFilterPipe } from './shared/pipe/label-filter.pipe';
import { ColumnSortPipe } from './shared/pipe/column-sort.pipe';
import { RfisFilterPipe } from './shared/pipe/rfis/rfis-filter.pipe';
import { SortByPipe } from './shared/pipe/sort-by.pipe';


@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        DashboardComponent,
        FieldErrorDisplayComponent,
        SecureRouteComponent,
        ControlMessagesComponent,
        AlertComponent,
        GeneralInfoComponent,
        ContactUsComponent,
        DocComponent,
        BreadcrumbComponent,
        RfisComponent,
        PaymentsComponent,
        MapsComponent,
        NotificationsComponent,     
        FilterAllColumnPipe,
        DocFilterPipe,
        TasksComponent,
        SortgridPipe,
        SystemadminComponent,
        CommentsComponent,
        LabelFilterPipe,   
        ColumnSortPipe, RfisFilterPipe, ConfirmationDialogComponent, UserManagementComponent, SortByPipe,     
    ],
    imports: [         
        BrowserModule,           
        BrowserAnimationsModule,
        AppRoutingModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule,
        HttpModule,
        JsonpModule,
        Ng4LoadingSpinnerModule,
        AngularMultiSelectModule,      
        NgxPaginationModule, 
        Ng2SearchPipeModule,
        Ng2OrderModule,
        NgbModule.forRoot(),
        ToastModule.forRoot(),  
        ConfirmationModalModule.forRoot({}),
        //FileUploaderModule,
        BootstrapSwitchModule.forRoot() 
    ],
    providers: [
        AuthGuard,
        AuthenticationService,
        AlertService,
        { provide: LocationStrategy, useClass: HashLocationStrategy },
        CookieService,
        ApiServicesService,
        DocService,
        PagerService,
        ManagelabelService,
        CommonService,
        RfisService,
        ConfirmationDialogService  
    ],
    entryComponents: [ConfirmationDialogComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
