import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router) { }

    //function to check if user session exist or not while navigate from one route to another
    canActivate() {
        if (localStorage.getItem('currentUser')) {
            console.log(localStorage.getItem('currentUser'))
            return true;
        }
        this.router.navigate(['/login']);
        return false;
    }
}

