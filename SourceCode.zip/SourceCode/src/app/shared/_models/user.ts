export class User {
    first_name: string;
    last_name: string;
    project_ids: Array<string>;
    roles: Array<string>;
    _id: string;
}