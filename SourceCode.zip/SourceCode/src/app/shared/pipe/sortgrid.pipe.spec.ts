import { SortgridPipe } from './sortgrid.pipe';

describe('SortgridPipe', () => {
  it('create an instance', () => {
    const pipe = new SortgridPipe();
    expect(pipe).toBeTruthy();
  });
});
