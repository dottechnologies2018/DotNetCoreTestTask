import { ColumnSortPipe } from './column-sort.pipe';

describe('ColumnSortPipe', () => {
  it('create an instance', () => {
    const pipe = new ColumnSortPipe();
    expect(pipe).toBeTruthy();
  });
});
