import { RfisFilterPipe } from './rfis-filter.pipe';

describe('RfisFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new RfisFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
