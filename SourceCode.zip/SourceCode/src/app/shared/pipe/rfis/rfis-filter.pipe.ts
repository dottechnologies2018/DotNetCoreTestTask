import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'rfisFilter'
})
export class RfisFilterPipe implements PipeTransform {
    transform(items: any, subjectSearchString: string, lastMessageSearchString: string, authorSearchString: string, documentSearchString: string, dateSearchString: string, searchStringfilter: any, isAnd: boolean): any {
        if (items && items.length) {
            return items.filter(item => {
                if (subjectSearchString && item.subject.toLowerCase().indexOf(subjectSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (lastMessageSearchString && item.lastMessage.toLowerCase().indexOf(lastMessageSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (authorSearchString && item.author.toLowerCase().indexOf(authorSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (documentSearchString && item.document.toLowerCase().indexOf(documentSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (dateSearchString && item.date.toLowerCase().indexOf(dateSearchString.toLowerCase()) === -1) {
                    return false;
                }                
                return true;
            })
        }
        else {
            return items;
        }
    }  

}
