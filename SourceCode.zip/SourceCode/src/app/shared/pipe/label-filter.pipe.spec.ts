import { LabelFilterPipe } from './label-filter.pipe';

describe('LabelFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new LabelFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
