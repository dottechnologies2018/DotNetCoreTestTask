import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'docFilter'
})
export class DocFilterPipe implements PipeTransform {
    transform(items: any, nameSearchString: string, projectSearchString: string, labelsSearchString: string, authorSearchString: string, typeSearchString: string, dateSearchString: string, searchStringfilter: any, isAnd: boolean): any {
        if (items && items.length) {         
            return items.filter(item => {
                if (nameSearchString && item.name.toLowerCase().indexOf(nameSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (projectSearchString && item.project_name.toLowerCase().indexOf(projectSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (labelsSearchString && item.labels.toLowerCase().indexOf(labelsSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (authorSearchString && item.author.toLowerCase().indexOf(authorSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (typeSearchString && item.type.toLowerCase().indexOf(typeSearchString.toLowerCase()) === -1) {
                    return false;
                }
                if (dateSearchString && item.date.toLowerCase().indexOf(dateSearchString.toLowerCase()) === -1) {
                    return false;
                }
                return true;
            })
        }
        else {
            return items;
        }
    }  

}
