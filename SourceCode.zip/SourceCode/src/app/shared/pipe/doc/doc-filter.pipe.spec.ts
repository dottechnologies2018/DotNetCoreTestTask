import { DocFilterPipe } from './doc-filter.pipe';

describe('DocFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DocFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
