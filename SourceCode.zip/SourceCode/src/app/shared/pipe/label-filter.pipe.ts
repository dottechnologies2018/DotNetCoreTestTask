import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'labelFilter'
})
export class LabelFilterPipe implements PipeTransform {
    transform(labels: any, searchText: any): any {
        if (searchText == null) return labels;
        return labels.filter(function (label) {
            return label.itemName.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
        })
    }
}
