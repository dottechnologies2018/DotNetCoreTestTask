import { FilterAllColumnPipe } from './filter-all-column.pipe';

describe('FilterAllColumnPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterAllColumnPipe();
    expect(pipe).toBeTruthy();
  });
});
