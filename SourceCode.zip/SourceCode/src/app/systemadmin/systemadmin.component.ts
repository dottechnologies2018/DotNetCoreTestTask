import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-systemadmin',
  templateUrl: './systemadmin.component.html',
  styleUrls: ['./systemadmin.component.css']
})
export class SystemadminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
