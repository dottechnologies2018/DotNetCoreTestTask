import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { AuthGuard } from '../app/shared/_guards/index';
import { Router, CanActivate } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    constructor(private _authGuard: AuthGuard, private _router: Router,public _toastr: ToastsManager, vcr: ViewContainerRef) {
        this._toastr.setRootViewContainerRef(vcr);
    }
    ngOnInit() {
        if (!this._authGuard.canActivate()) {
            this._router.navigate(['/login']);
        }
        else {
            
        }
    }
}
