import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { AuthGuard } from '../shared/_guards/index';
import { Router, CanActivate } from '@angular/router';

import { AuthenticationService } from '../services/authentication.service';
import { AlertService } from '../services/alert.service';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
    constructor(private authenticationService: AuthenticationService, private alertService: AlertService, private http: Http, private _httpclient: HttpClient, private _authGuard: AuthGuard, private router: Router) { }

    ngOnInit() {
        if (!this._authGuard.canActivate()) {
            this.router.navigate(['/login']);
        }
       
    }    
}

