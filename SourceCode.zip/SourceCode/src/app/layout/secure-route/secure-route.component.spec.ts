import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecureRouteComponent } from './secure-route.component';

describe('SecureRouteComponent', () => {
  let component: SecureRouteComponent;
  let fixture: ComponentFixture<SecureRouteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecureRouteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecureRouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
