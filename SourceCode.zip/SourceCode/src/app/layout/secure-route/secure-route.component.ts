import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { AlertService } from '../../services/alert.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';

@Component({
    selector: 'app-secure-route',
    templateUrl: './secure-route.component.html',
    styleUrls: ['./secure-route.component.css']
})
export class SecureRouteComponent implements OnInit {
    tasks: string;
    docs: string;
    rfis: string;
    fullname = "";
    IsadminAccess = false;
    interval: any;
    _currentYear: any;
    constructor(private authenticationService: AuthenticationService, private router: Router, private alertService: AlertService, private spinnerService: Ng4LoadingSpinnerService, public _toastr: ToastsManager, vcr: ViewContainerRef) {
        this._toastr.setRootViewContainerRef(vcr);
    }

    ngOnInit() {
        //Check if user session exists or not
        if (localStorage.getItem('currentUser') != null && localStorage.getItem('currentUser') != '') {
            this.getAlertCounts();
            var currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser._id != "") {
                var d = new Date();
                this._currentYear = d.getFullYear();
                this.IsadminAccess = this.authenticationService.isAdminRole();
                this.fullname = currentUser.first_name + ' ' + currentUser.last_name;
                this.interval = setInterval(() => this.getAlertCounts(), 60000);
            }
        }
        else {
            this.router.navigate(['/login']);
        }
    }

    //function to logout user from application and api
    logout() {
        this.spinnerService.show();
        this.authenticationService.logout()
            .subscribe(res => {
                this.spinnerService.hide();
                clearInterval(this.interval);            
                let resSTR = JSON.stringify(res);            
                let resJSON = JSON.parse(resSTR);              
                if (resJSON.status == 200) {
                    localStorage.removeItem('currentUser');
                    this.router.navigate(['/login']);
                }
                else {
                    this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 1000 });
                }
            },
            error => {
                this.spinnerService.hide();
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 1000 });
            });
    }

    //function to get alert count for tasks, docs, rfis from api
    getAlertCounts() {
        console.log("calling get alerts counts api")
        this.authenticationService.getService()
            .subscribe(res => {
                this.tasks = res.json().tasks;
                this.docs = res.json().docs;
                this.rfis = res.json().rfis;
            },
            error => {
                this._toastr.error("Something is went wrong, contact site administrator", 'Error !', { toastLife: 1000 });
            });
    }
}

