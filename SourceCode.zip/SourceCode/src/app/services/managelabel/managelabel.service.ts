import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { ApiServicesService } from '../api-services.service';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ManagelabelService {
    constructor(private http: Http, private _apiServicesService: ApiServicesService) { }

    //function for to add new User-defined label
    public addUserLabel(labelName) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('label_name', labelName);
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'baf/DocumentLabelAdd', body, { headers: headers })
            .map((response: Response) => {
                return response;
            });
    }

    //function for delete User-defined label 
    public deleteUserLabel(labelName) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('label_name', labelName);
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'baf/DocumentLabelDelete', body, { headers: headers })
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }

    private handleError(error: Response | any) {
        // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}


