import { TestBed, inject } from '@angular/core/testing';

import { ManagelabelService } from './managelabel.service';

describe('ManagelabelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ManagelabelService]
    });
  });

  it('should be created', inject([ManagelabelService], (service: ManagelabelService) => {
    expect(service).toBeTruthy();
  }));
});
