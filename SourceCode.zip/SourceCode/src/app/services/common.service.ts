import { Injectable } from '@angular/core';

@Injectable()
export class CommonService {
    constructor() { }

    //Function for removing duplicates object in array
    removeDuplicates(originalArray, prop) {
        var newArray = [];
        var lookupObject = {};
        for (var i in originalArray) {
            lookupObject[originalArray[i][prop]] = originalArray[i];
        }
        for (i in lookupObject) {
            newArray.push(lookupObject[i]);
        }
        return newArray;
    }

    //Function to remove duplicate string from comma separated string and return an array of string
    convertStringToArray(value) {
        return (value || '').split(',').filter(Boolean).filter(function (item, index, all) {
            return (index === all.indexOf(item));
        });
    }

    //Function for search specific object in array list
    search(nameKey, myArray) {
        for (var i = 0; i < myArray.length; i++) {
            if (myArray[i].name === nameKey) {
                return myArray[i];
            }
        }
    }

    //Function for setting the grid height in any type of screens
    calculateGridHeight() {
        var outerDivHeight = $('div.one').height();       
        var breadcrumbHeight = $('div#breadcrumb-div').height();    
        var cardheader = $("div.card-header").height();    
        var calculatedHeight = outerDivHeight - (breadcrumbHeight + cardheader);      
        $('div.card tbody').css("max-height", calculatedHeight);
    }

    removeSpecialCharacterFromString(str) {
        return str.replace(/[^a-zA-Z ]/g, "");
    }
}
