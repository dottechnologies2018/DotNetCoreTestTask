import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { ApiServicesService } from '../api-services.service';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class DocService {
    headers: Headers;
    options: RequestOptions;
    constructor(private http: Http, private _apiServicesService: ApiServicesService) { }

    //function to get documents summary
    public getDocumentsSummary() {
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/GetDocumentsSummary')
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }

    //function to get User defined labels
    public getUserLablesList() {
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'baf/DocumentLabelsFetch')
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }

    //function to get document version
    public getDocumentVersion(docId, projectId) {
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/GetDocumentVersionsList?document_id=' + docId + '&project_id=' + projectId)
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }

    //Function to assign label to doc
    public assignLabelToDoc(labelName, docId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('label_name', labelName);
        urlSearchParams.append('document_id', docId);
        urlSearchParams.append('op', 'add');
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'baf/DocumentLabelManage', body, { headers: headers })
            .map((response: Response) => {
                return response;
            });
    }

    //Function to remove assign label to doc
    public removeLabelToDoc(labelName, docId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('label_name', labelName);
        urlSearchParams.append('document_id', docId);
        urlSearchParams.append('op', 'remove');
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'baf/DocumentLabelManage', body, { headers: headers })
            .map((response: Response) => {
                return response;
            });
    }

    //Function to upload document to doc
    public uploadDocToDoc(projectId, docId, file) {
        var query = this._apiServicesService.getApiBaseUrl() + 'baf/DocumentPreload?project_id=' + projectId + '&document_master_id=' + docId;
        const frmData = new FormData();
        frmData.append(file.name, file, file.name);
        return this.http.post(query, frmData)
            .map((response: Response) => {
                return response;
            });
    }

    //Function to filter label save 
    public filterLabelsSave(labels) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('labels', labels);
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'dot/DocumentFilterLabelSave', body, { headers: headers })
            .map((response: Response) => {
                return response;
            });
    }

    public getDocumentDownloadPath() {
        return this._apiServicesService.getApiBaseUrl() + 'baf/DocumentVersionDownload';
    }

    //Function to multiple labels assignments to multiple doc
    public multipleLabelAssignmentToDocs(docIds, labels) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'dot/DocGroupLabelManage', JSON.stringify({ docIds: docIds, labels: labels, op: 'add' }), options)
            .map((response: Response) => {
                return response;
            });
    }

    //Function to multiple labels De-assignments to multiple doc
    public multipleLabelDeAssignmentToDocs(docIds, labels) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'dot/DocGroupLabelManage', JSON.stringify({ docIds: docIds, labels: labels, op: 'remove' }), options)
            .map((response: Response) => {
                return response;
            });
    }

    //Function for perform group download 
    public groupDownloadDocs(docIds, projectIds) {
        window.location.href = this._apiServicesService.getApiBaseUrl() + 'dot/DocumentGroupDownload?document_ids=' + docIds + '&project_ids=' + projectIds;
    }

    //function to fetch Document Group Labels 
    public getDocumentGroupLabels(docIds) {
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/DocGroupLabelsFetch?document_ids=' + docIds)
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }

    //function to handle exception from Api response.   
    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }
}
