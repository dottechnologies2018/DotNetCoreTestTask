import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { ApiServicesService } from '../services/api-services.service';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class AuthenticationService {
    headers: Headers;
    options: RequestOptions;
    constructor(private http: Http, private httpClient: HttpClient, private _apiServicesService: ApiServicesService) { }

    /** 
      * Function to remove user from local storage and also from Api
      * Return response from Api
    **/
    public logout(): Observable<any> { 
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'etc/LoginPost', null, null)
            .map((response: Response) => {
                return response;
            });
    }


    /** 
      * Function to check authenticate user with Api
      * Return response from Api
    **/
    public login(email: string, password: string): Observable<any> {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers});
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'etc/LoginPost', JSON.stringify({ email: email, password: password }), options)
            .map((res: Response) => {             
                return res.json();
            })
            .catch(this.handleErrorObservable);
    }

    /** 
      * Function to get header count(tasks,docs,rfis)
      * Return response from Api
    **/
    public getService(): Observable<Response> {
        let myHeaders = new Headers();
        myHeaders.set('Content-Type', 'application/json');
        let myParams = new URLSearchParams();
        myParams.set('UserNameEmail', localStorage.getItem("UserNameEmail"));
        let options = new RequestOptions({ headers: myHeaders, params: myParams });
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/GetAlerts', options)
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }


    /** 
      * Function to check if logged user having admin role or not
      * Return response from based on Api
    **/
    public isAdminRole(): boolean {
        let _currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (_currentUser != null && _currentUser != "") {
            var _dataAdmin = _currentUser.roles.indexOf("BW-Data-Admin");
            var _admin = _currentUser.roles.indexOf("BW-Admin");
            if (parseInt(_dataAdmin) >= 0 && parseInt(_admin)) {
                return true;
            }
            else {
                return false;
            }
        }
        return false;
    }

    /** 
      * Function to get documents summary
      * Return response from Api
    **/
    public getDocumentsSummary(): Observable<Response> {      
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/GetDocumentsSummary')
            .map((response: Response) => {
                return response;
            }).catch(this.handleError);
    }


    /** 
      * Function to handle exception from Api response.
    **/
    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

    /** 
      * Function to handle exception from Api response.
    **/
    private handleErrorObservable(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.message || error);
    }
}


