import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { ApiServicesService } from '../api-services.service';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class RfisService {
    headers: Headers;
    options: RequestOptions;
    constructor(private http: Http, private _apiServicesService: ApiServicesService) { }

    //function to getting rfi's summary
    public getRFISummary(docId, projectId, timestamp) {
        //var parameters = "?document_id=" + docId + '&project_id=' + projectId + '&doc_version_timestamp=' + timestamp;
        var parameters = "?document_id=" + docId;     
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/GetRfisSummary' + (docId != null && docId != "" ? parameters : ""))
            .map((response: Response) => {
                return response;
            });
    }

    //function to getting rfi Role Names
    public getRfiRoleNames(projectId) {
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'dot/GetRfiRoleNames?project_id=' + projectId)
            .map((response: Response) => {
                return response;
            });
    }

    //function to start a new rfi's 
    public docRFIStart(projectId, docId, doc_version_timestamp, subject, rfi_text, recipient_roles) {     
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('project_id', projectId);
        urlSearchParams.append('document_id', docId);
        urlSearchParams.append('doc_version_timestamp', doc_version_timestamp);
        urlSearchParams.append('rfi_text', rfi_text);
        urlSearchParams.append('subject', subject);
        urlSearchParams.append('recipient_roles', recipient_roles);
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'dot/DocRfiStart', body, { headers: headers })
            .map((response: Response) => {
                return response;
            });
    }

    //Function to close the RFI 
    public rfiClose(rfiId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('rfi_id', rfiId);
        let body = urlSearchParams.toString()
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'baf/RFIClose', body, { headers: headers })
            .map((response: Response) => {
                return response;
            });
    }

    //function to getting rfi's details
    public getRFIDetails(rfiId) {
        return this.http.get(this._apiServicesService.getApiBaseUrl() + 'baf/RFIDetailsFetch?rfi_id=' + rfiId)
            .map((response: Response) => {
                return response;
            });
    }

    public rfiUpdateComment(rfiId, comment) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this._apiServicesService.getApiBaseUrl() + 'dot/RFIMessageSubmit', JSON.stringify({ rfi_id: rfiId, text: comment }), options)
            .map((res: Response) => {
                console.log(res)
                return res;
            })
       
    }
}
