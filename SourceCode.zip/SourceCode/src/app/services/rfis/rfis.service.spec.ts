import { TestBed, inject } from '@angular/core/testing';

import { RfisService } from './rfis.service';

describe('RfisService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RfisService]
    });
  });

  it('should be created', inject([RfisService], (service: RfisService) => {
    expect(service).toBeTruthy();
  }));
});
