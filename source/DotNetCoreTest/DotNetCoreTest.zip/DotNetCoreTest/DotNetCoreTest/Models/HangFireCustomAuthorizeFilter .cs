﻿using Hangfire.Annotations;
using Hangfire.Dashboard;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetCoreTest.Models
{
    public class HangFireCustomAuthorizeFilter : IDashboardAuthorizationFilter
    {
        private readonly string[] _roles;

        public HangFireCustomAuthorizeFilter(params string[] roles)
        {
            _roles = roles;
        }

        public bool Authorize(DashboardContext context)
        {
            var httpContext = ((AspNetCoreDashboardContext)context).HttpContext;
            var result = _roles.Aggregate(false, (current,role) => current || httpContext.User.IsInRole(role));
            // Otherwise redirect to your specific authorized area
            //if (result == false)
            //{
            //    httpContext.Response.Redirect("https://www.google.co.in");
            //}           
            return result;
        }
    }

}
