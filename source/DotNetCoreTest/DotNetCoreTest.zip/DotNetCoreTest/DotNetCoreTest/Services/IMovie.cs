﻿using DotNetCoreTest.data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetCoreTest.Services
{
   public interface IMovie
    {
        List<TbMovies> getAllMovies();
        void MovieApiData();
    }
}
