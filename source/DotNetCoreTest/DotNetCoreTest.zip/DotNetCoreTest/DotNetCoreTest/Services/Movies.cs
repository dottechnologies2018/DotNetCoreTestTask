﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetCoreTest.data;
using DotNetCoreTest.Models;
using RestSharp;

namespace DotNetCoreTest.Services
{
    public class Movies : IMovie
    {
        public List<TbMovies> getAllMovies()
        {
            using (var datacontext = new core_demoContext())
            {
                return datacontext.TbMovies.ToList();
            }
        }

        public void MovieApiData()
        {
            Console.WriteLine("recurring!");
            var client = new RestClient("https://api.themoviedb.org/3/movie/550/lists?page=1&language=en-US&api_key=ed9c482d8e761477d4c8c1a0a8abeaef");
            var request = new RestRequest(Method.GET);
            IRestResponse response = client.Execute(request);
            if (response.IsSuccessful)
            {
                MoviesModels myDeserializedObjList = (MoviesModels)Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content, typeof(MoviesModels));
                if (myDeserializedObjList.results.Count > 0)
                {
                    using (var datacontext = new core_demoContext())
                    {
                        TbMovies obj = null;
                        for (int i = 0; i < myDeserializedObjList.results.Count; i++)
                        {
                            obj = new TbMovies();
                            obj.MovieId = Convert.ToInt32(myDeserializedObjList.results[i].id);
                            obj.Name = myDeserializedObjList.results[i].name;
                            obj.Description = myDeserializedObjList.results[i].description;
                            obj.ListType = myDeserializedObjList.results[i].list_type;
                            obj.PosterPath = myDeserializedObjList.results[i].poster_path;
                            datacontext.TbMovies.Add(obj);
                        }
                        datacontext.SaveChanges();
                    }

                }
            }

        }

    }
}
