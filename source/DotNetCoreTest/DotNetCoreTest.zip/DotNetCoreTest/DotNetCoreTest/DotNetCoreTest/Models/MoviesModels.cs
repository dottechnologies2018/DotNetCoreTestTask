﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetCoreTest.Models
{
    public class MoviesModels
    {
        public int id { get; set; }
        public int page { get; set; }
        public List<MovieList> results { get; set; }
        public int total_pages { get; set; }
        public int total_results { get; set; }

    }
    public class MovieList
    {
        public string id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string list_type { get; set; }
        public string poster_path { get; set; }
    }
}
