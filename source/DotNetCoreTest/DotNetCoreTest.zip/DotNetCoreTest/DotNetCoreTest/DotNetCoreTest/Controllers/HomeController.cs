﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DotNetCoreTest.Models;
using RestSharp;
using Hangfire;
using DotNetCoreTest.Services;
using Microsoft.AspNetCore.Authorization;
using DotNetCoreTest.data;

namespace DotNetCoreTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly IMovie _movie;
        public HomeController(IMovie movie)
        {
            _movie = movie;
        }
        public IActionResult Index()
        {          
            return View();
        }

        [Authorize]
        public IActionResult GetMovies()
        {
            var result = _movie.getAllMovies();
            return View(result);
        }
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


    }
}
