﻿using System;
using System.Collections.Generic;

namespace DotNetCoreTest.data
{
    public partial class Schema
    {
        public int Version { get; set; }
    }
}
