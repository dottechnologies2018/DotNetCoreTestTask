﻿using System;
using System.Collections.Generic;

namespace DotNetCoreTest.data
{
    public partial class TbMovies
    {
        public int Id { get; set; }
        public int? MovieId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ListType { get; set; }
        public string PosterPath { get; set; }
        public DateTime? AddedDate { get; set; }
    }
}
